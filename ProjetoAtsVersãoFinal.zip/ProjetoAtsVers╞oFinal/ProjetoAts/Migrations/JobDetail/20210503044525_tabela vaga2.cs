﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoAts.Migrations.JobDetail
{
    public partial class tabelavaga2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

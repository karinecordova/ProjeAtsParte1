﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoAts.Migrations
{
    public partial class modificacoescurriculo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Activities",
                table: "CurriculoDetails",
                type: "nvarchar(250)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Company",
                table: "CurriculoDetails",
                type: "nvarchar(100)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Course",
                table: "CurriculoDetails",
                type: "nvarchar(100)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Phone",
                table: "CurriculoDetails",
                type: "nvarchar(13)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "CurriculoDetails",
                type: "nvarchar(100)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Sexo",
                table: "CurriculoDetails",
                type: "nvarchar(1)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Working",
                table: "CurriculoDetails",
                type: "nvarchar(1)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dataEntrada",
                table: "CurriculoDetails",
                type: "nvarchar(10)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dataSaida",
                table: "CurriculoDetails",
                type: "nvarchar(10)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dateCourse",
                table: "CurriculoDetails",
                type: "nvarchar(10)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Activities",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Company",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Course",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Phone",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Sexo",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "Working",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "dataEntrada",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "dataSaida",
                table: "CurriculoDetails");

            migrationBuilder.DropColumn(
                name: "dateCourse",
                table: "CurriculoDetails");
        }
    }
}

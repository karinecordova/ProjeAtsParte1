﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetoAts.Migrations
{
    public partial class inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CurriculoDetails",
                columns: table => new
                {
                    CurriculoDetailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    Cpf = table.Column<string>(type: "nvarchar(11)", nullable: true),
                    BirthDate = table.Column<string>(type: "nvarchar(08)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(60)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurriculoDetails", x => x.CurriculoDetailId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CurriculoDetails");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoAts.Models
{
    public class CurriculoDetail
    {
        [Key]
        public int CurriculoDetailId { get; set; }

        [Column(TypeName ="nvarchar(100)")]
        public string Name { get; set; }

        [Column(TypeName = "nvarchar(11)")]
        public string Cpf { get; set; }

        [Column(TypeName = "nvarchar(08)")]
        public string BirthDate { get; set; }

        [Column(TypeName = "nvarchar(1)")]
        public string Sexo { get; set; }

        [Column(TypeName = "nvarchar(13)")]
        public string Phone { get; set; }

        [Column(TypeName = "nvarchar(60)")]
        public string Email { get; set; }        

        [Column(TypeName = "nvarchar(100)")]
        public string Course { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public string dateCourse { get; set; }

        [Column(TypeName = "nvarchar(1)")]
        public string Working { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string Company { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string Role { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public string dataEntrada { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public string dataSaida { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        public string Activities { get; set; }





    }
}

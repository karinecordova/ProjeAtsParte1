﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProjetoAts.Models;

namespace ProjetoAts.Models
{
    public class CurriculoDetailContext: DbContext
    {
        public CurriculoDetailContext(DbContextOptions<CurriculoDetailContext> options):base(options)
        {

        }
        public DbSet<CurriculoDetail> CurriculoDetails { get; set; }
        
    }
}

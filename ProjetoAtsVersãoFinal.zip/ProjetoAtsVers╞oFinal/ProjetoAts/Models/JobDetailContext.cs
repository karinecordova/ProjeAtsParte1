﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ProjetoAts.Models
{
    public class JobDetailContext:DbContext
    {
        public JobDetailContext(DbContextOptions<JobDetailContext> options) : base(options)
        {

        }
        public DbSet<JobDetail> JobDetails { get; set; }
        
    }
}

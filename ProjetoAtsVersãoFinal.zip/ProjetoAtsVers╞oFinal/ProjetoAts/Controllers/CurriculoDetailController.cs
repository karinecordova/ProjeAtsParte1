﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoAts.Models;

namespace ProjetoAts.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurriculoDetailController : ControllerBase
    {
        private readonly CurriculoDetailContext _context;

        public CurriculoDetailController(CurriculoDetailContext context)
        {
            _context = context;
        }

        // GET: api/CurriculoDetail
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CurriculoDetail>>> GetCurriculoDetails()
        {
            return await _context.CurriculoDetails.ToListAsync();
        }

        // GET: api/CurriculoDetail/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CurriculoDetail>> GetCurriculoDetail(int id)
        {
            var curriculoDetail = await _context.CurriculoDetails.FindAsync(id);

            if (curriculoDetail == null)
            {
                return NotFound();
            }

            return curriculoDetail;
        }

        // PUT: api/CurriculoDetail/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCurriculoDetail(int id, CurriculoDetail curriculoDetail)
        {
            if (id != curriculoDetail.CurriculoDetailId)
            {
                return BadRequest();
            }

            _context.Entry(curriculoDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CurriculoDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CurriculoDetail
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CurriculoDetail>> PostCurriculoDetail(CurriculoDetail curriculoDetail)
        {
            _context.CurriculoDetails.Add(curriculoDetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCurriculoDetail", new { id = curriculoDetail.CurriculoDetailId }, curriculoDetail);
        }

        // DELETE: api/CurriculoDetail/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCurriculoDetail(int id)
        {
            var curriculoDetail = await _context.CurriculoDetails.FindAsync(id);
            if (curriculoDetail == null)
            {
                return NotFound();
            }

            _context.CurriculoDetails.Remove(curriculoDetail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CurriculoDetailExists(int id)
        {
            return _context.CurriculoDetails.Any(e => e.CurriculoDetailId == id);
        }
    }
}
